def greedy_allocate(packages, weight_capacity, value_col="delivery_value",
                    weight_col="weight"):
    items = packages.copy()
    items["score"] = items[value_col] / items[weight_col].replace(0, 1)
    items = items.sort_values("score", ascending=False)

    selected = []
    total_weight = 0.0
    total_value = 0.0

    for _, row in items.iterrows():
        w = float(row[weight_col])
        if total_weight + w <= weight_capacity:
            selected.append(row)
            total_weight += w
            total_value += float(row[value_col])

    return selected, total_weight, total_value
