def agli_allocate(packages, weight_capacity, value_col="delivery_value",
                   weight_col="weight"):
    # Greedy seed
    selected, total_weight, total_value = greedy_allocate(
        packages, weight_capacity, value_col, weight_col
    )

    selected_ids = {id(row) for row in selected}
    remaining = [row for _, row in packages.iterrows()
                 if id(row) not in selected_ids]

    # Local improvement: try profitable additions and replacements.
    improved = True
    while improved:
        improved = False

        for row in remaining:
            w = float(row[weight_col])
            v = float(row[value_col])

            if total_weight + w <= weight_capacity:
                selected.append(row)
                total_weight += w
                total_value += v
                remaining.remove(row)
                improved = True
                break

        if not improved and selected:
            for i, old in enumerate(selected):
                old_w = float(old[weight_col])
                old_v = float(old[value_col])

                for row in remaining:
                    new_w = float(row[weight_col])
                    new_v = float(row[value_col])

                    if (total_weight - old_w + new_w <= weight_capacity
                            and new_v > old_v):
                        selected[i] = row
                        remaining.remove(row)
                        remaining.append(old)
                        total_weight = total_weight - old_w + new_w
                        total_value = total_value - old_v + new_v
                        improved = True
                        break
                if improved:
                    break

    return selected, total_weight, total_value
