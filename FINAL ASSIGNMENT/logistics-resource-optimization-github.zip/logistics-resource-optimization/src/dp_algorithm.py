def knapsack_dp(packages, weight_capacity, value_col="delivery_value",
                   weight_col="weight"):
    # Standard 0/1 weight-based DP baseline.
    items = packages.reset_index(drop=True)
    W = int(weight_capacity)

    dp = [0.0] * (W + 1)

    for _, row in items.iterrows():
        w = int(round(float(row[weight_col])))
        v = float(row[value_col])
        if w <= 0 or w > W:
            continue
        for capacity in range(W, w - 1, -1):
            dp[capacity] = max(dp[capacity], dp[capacity - w] + v)

    return dp[W]
