# Intelligent Algorithmic Solution for Large-Scale Logistics Resource Optimization

## Algorithms
- Dynamic Programming (DP) baseline
- Greedy baseline
- AGLI – Adaptive Greedy-Seeded Local Improvement

## Experiments
Input sizes: 100, 500, 1000, 5000, 10000
Capacities: 500, 1000, 2500, 5000 kg
Operating conditions: Normal, High-Priority, Capacity-Constrained

## Metrics
Execution time, memory usage, solution value, capacity utilization,
optimality gap, feasibility, and scalability.

## Tools
Python, Google Colab, pandas, NumPy, Matplotlib.

## How to run
1. Put the dataset in `data/`.
2. Open `notebooks/logistics_optimization.ipynb` in Google Colab or Jupyter.
3. Run the cells from top to bottom.
